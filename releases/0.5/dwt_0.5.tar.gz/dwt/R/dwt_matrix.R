## ======================================================================
## File     : dwt_matrix.R
## Purpose  : R code for the Discrete Wavelet Transform (DWT).
## Updated  : pfc@stat.osu.edu, Mar 2009.
## 
## Copyright 2002--2009, Peter F. Craigmile, All Rights Reserved
## Address comments about this software to pfc@stat.osu.edu.
##
## The use of this software is permitted for academic purposes only,
## provided its use is acknowledged.  Commercial use is not allowed
## without the permission of the author.  This software is made available
## AS IS, and no warranty -- about the software, its performance, or
## its conformity to any specification -- is given or implied.
## ======================================================================


## ======================================================================
## Purpose : Calculate the wavelet transform matrix for the dwt
##           object 'dx'.
## Updated : pfc@stat.osu.edu, Oct 2001. 
## ======================================================================

dwt.matrix <- function (dx)
{
  dz <- dwt.update(dx, rep(0, dx$N))
  W  <- matrix(0, dx$N, dx$N)
  r  <- 1
  
  for (j in 1:dx$J)
    for (k in 1:dx$Nj[j])
    {
      dz$W[[j]][k] <- 1
      W[r,]        <- idwt(dz)
      dz$W[[j]][k] <- 0
      r            <- r + 1
    }

  for (k in 1:dx$Nj[dx$J])
  {
    dz$V[k] <- 1
    W[r,]   <- idwt(dz)
    dz$V[k] <- 0
    r       <- r + 1
  }

  W	
}




## ======================================================================
## Purpose : Calculate a subset of wavelet transform matrix for the dwt
##           object 'dx'.  Only include the rows corresponding
##           to the first wavelet coefficient per level, and the first
##           level dx$J scaling coefficient.
## Updated : pfc@stat.osu.edu, Oct 2001. 
## ======================================================================

dwt.matrix.elems <- function (dx)
{
  dz <- dwt.update(dx, rep(0, dx$N))
  W  <- matrix(0, dx$J+1, dx$N)
  
  for (j in 1:dx$J)
  {
    dz$W[[j]][1] <- 1
    W[j,]        <- idwt(dz)
    dz$W[[j]][1] <- 0
  }

  dz$V[1]    <- 1
  W[dx$J+1,] <- idwt(dz)
  W	
}


