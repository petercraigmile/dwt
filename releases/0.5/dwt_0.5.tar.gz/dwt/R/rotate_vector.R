## ======================================================================
## File     : rotate_vector.R
## Updated  : pfc@stat.osu.edu, Apr 2005.
## 
## Copyright 2002--2009, Peter F. Craigmile, All Rights Reserved
## Address comments about this software to pfc@stat.osu.edu.
##
## The use of this software is permitted for academic purposes only,
## provided its use is acknowledged.  Commercial use is not allowed
## without the permission of the author.  This software is made available
## AS IS, and no warranty -- about the software, its performance, or
## its conformity to any specification -- is given or implied.
## ======================================================================



## ======================================================================
## Purpose : Rotate the vector 'x' 'delta' units to the right.
## Updated : pfc@stat.osuedu, June 2002.
## ======================================================================

rotate.vector <- function (x, delta)
{
  n <- length(x)
  if (n > 0)
  {
    mod.delta <- n-(delta %% n)
    c(x,x)[(mod.delta+1):(mod.delta+n)]
  }
  else x
}

