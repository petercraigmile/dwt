## ======================================================================
## File    : dwt_filters_cascades.R
## Purpose : R code to define and manipulate DWT scaling filters
##           at many different wavelet levels.
## Updated : pfc@stat.osu.edu
## 
## Copyright 2002--2009, Peter F. Craigmile, All Rights Reserved
## Address comments about this software to pfc@stat.ohio-state.edu.
##
## The use of this software is permitted for academic purposes only,
## provided its use is acknowledged.  Commercial use is not allowed
## without the permission of the author.  This software is made available
## AS IS, and no warranty -- about the software, its performance, or
## its conformity to any specification -- is given or implied.
## ======================================================================



## ======================================================================
## Purpose : Using the dwt.filter object 'filter', calculate the
##           all the wavelet and scaling filters up to level 'J'.
## Assumes : 'J' is an integer > 0.
## Updated : pfc@stat.ohio-state.edu, Mar 2003.
## ======================================================================

dwt.all.filters <- function (filter, J)
{
  scaling.list <- list(filter$scaling)
  wavelet.list <- list(filter$wavelet)

  if (J>1)
    for (j in 2:J)
    {
      fnext   <- dwt.next.filters(scaling.list[[j-1]], wavelet.list[[j-1]], j, filter)
      scaling.list[[j]] <- fnext$scaling
      wavelet.list[[j]] <- fnext$wavelet
    }

  list(scaling.list=scaling.list, wavelet.list=wavelet.list)
}





## ======================================================================
## Purpose : Given the wavelet filter 'prev.wavelet' and scaling filter
##           'prev.scaling' at level 'j'-1 calculate the level 'j' filters
##           using the dwt.filter object 'filter'.
## Assumes : 'j' is an integer > 1.
## Updated : pfc@stat.ohio-state.edu, Mar 2003.
## =====================================================================

dwt.next.filters <- function (prev.scaling, prev.wavelet, j, filter)
{
  Lj <- (2^j-1)*(filter$L-1)+1
  scalingz <- waveletz <- scalingp <- rep(0,Lj)
  
  scalingp[1:filter$L] <- filter$scaling
  Gp                   <- fft(scalingp)

  ms     <- 2*seq(length(prev.scaling))-1
  scalingz[ms] <- prev.scaling
  waveletz[ms] <- prev.wavelet

  list(scaling = Re(fft(fft(scalingz) * Gp, inverse=TRUE)),
       wavelet = Re(fft(fft(waveletz) * Gp, inverse=TRUE)))
}


