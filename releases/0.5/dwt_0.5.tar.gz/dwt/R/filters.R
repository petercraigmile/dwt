## ======================================================================
## Copyright 1998--2008, Peter F. Craigmile, All Rights Reserved
## Address comments about this software to pfc@stat.osu.edu.
##
## The use of this software is permitted for academic purposes only,
## provided its use is acknowledged.  Commercial use is not allowed
## without the permission of the author.  This software is made available
## AS IS, and no warranty -- about the software, its performance, or its
## conformity to any specification -- is given or implied.
## ======================================================================


## ======================================================================
## File     : filters.R
## Contains : Some standard operations for filters.
## Version  : 1.0
## Updated  : pfc@stat.osu.edu, Jul 2007.
##
## References:
##
##     D. B. Percival and A. T. Walden (2000),
##     Wavelet Methods for Time Series Analysis.
##     Cambridge, England: Cambridge University Press.
## ======================================================================




downsample.by.two <- function (x) {
  ## ======================================================================
  ## Only return the even valued elements of 'x'
  ## ======================================================================

  x[seq(2, length(x), 2)]
}



upsample.by.two <- function (x) {
  ## ======================================================================
  ## Interleave zeroes in the vector 'x', at every odd numbered position.
  ## ======================================================================

  as.numeric(rbind(0, x))
}



upsample.after.by <- function (x, n) {
  ## ======================================================================
  ## Interleave 'n' zeroes in the vector 'x', after every position.
  ## ======================================================================
  
  as.numeric(rbind(x, matrix(0, n, length(x))))
}



periodize.filter <- function (filter, n, L=length(filter)) {  
  ## ======================================================================
  ## periodize the filter 'filter' of length 'L'
  ## into a vector of length 'n'.
  ## ======================================================================

  ## This method is slower
  ## as.numeric(rowsum(filter, (0:(L-1)) %% n))

  ## use this instead
  rowSums(matrix(c(filter, rep(0, n - L %% n)), n))
}






circularly.filter <- function (x, f, L=length(f)) {
  ## ======================================================================
  ## Circularly filter the sequence 'x' using the filter 'f'.
  ## ======================================================================
  
  n <- length(x)
  
  ## do we need to periodize the filter?
  if (L > n)
    f <- periodize.filter(f, n, L)

  ## This method is slower
#  filter(x, f, "convolution", sides=1, circular=TRUE)

  ## instead we use the C function that the 'filter' function calls...
  .C("filter1", as.double(x), as.integer(n),
     as.double(f), as.integer(length(f)), 
     as.integer(1), as.integer(1), out = double(n), 
     NAOK = TRUE, PACKAGE = "stats")$out
}



center.of.energy <- function (f)
  ## ======================================================================
  ## Calculate the center of energy of the filter 'f'
  ## References: Wickerhauser (1994, p.171 and p.341)
  ##             Percival and Walden (2000, p.118)
  ## ======================================================================
{
  f.sq <- f^2
  sum((0:(length(f)-1)) * f.sq)/sum(f.sq)
}
