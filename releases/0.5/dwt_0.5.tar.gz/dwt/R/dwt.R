## ======================================================================
## File     : dwt.R
## Purpose  : R code for the Discrete Wavelet Transform (DWT).
## Requires : (1) The C functions "R_dwt_pyramid_down",
##                "R_dwt_pyramid_up" to be dynamically loaded.
## Updated  : pfc@stat.osu.edu, Mar 2009.
## 
## Copyright 2002--2009, Peter F. Craigmile, All Rights Reserved
## Address comments about this software to pfc@stat.osu.edu.
##
## The use of this software is permitted for academic purposes only,
## provided its use is acknowledged.  Commercial use is not allowed
## without the permission of the author.  This software is made available
## AS IS, and no warranty -- about the software, its performance, or
## its conformity to any specification -- is given or implied.
## ======================================================================



dwt.cascade.next <- function (V, filter, use.C=TRUE) {
  ## ======================================================================
  ## Given the scaling coefficients 'V' on level j-1,
  ## calculate the scaling '$V' and wavelet coefficients '$W'
  ## on the level j using the dwt filter object 'filter'.
  ## If use.C is TRUE, use C code to calculate this; otherwise use R code.
  ## ======================================================================

  n <- length(V)
  if (n%%2!=0)
    stop("The vector V must be of even length")

  if (use.C) {

    if (!is.loaded("R_dwt_pyramid_down", PACKAGE="dwt"))
      stop("The C function 'R_dwt_pyramid_down' must be dynamically loaded.")
    
    z <- double(n/2)
    results <- .C("R_dwt_pyramid_down",
                  as.double(V), as.integer(n), V = z, W = z,
                  as.double(filter$scaling), as.double(filter$wavelet),
                  as.integer(filter$L),
                  PACKAGE="dwt")

    list(V=results$V, W=results$W)    
  } else {    
    ## Optimization step: 'sel' is the vector that does the downsampling
    ## (I could also have used the function 'downsample.by.two').
    sel <- seq(2, n, 2)
    next.V <- circularly.filter(V, filter$scaling, filter$L)[sel]
    next.W <- circularly.filter(V, filter$wavelet, filter$L)[sel]
    
    list(V=next.V, W=next.W)
  }
}





dwt.cascade.previous <- function (V, W, filter, use.C=TRUE) {
  ## ======================================================================
  ## Given the scaling coefficients 'V' and wavelet coefficients 'W'
  ## on scale j+1, calculate the level j scaling coefficients using
  ## the dwt filter object 'filter'.
  ## If use.C is TRUE, use C code to calculate this; otherwise use R code.
  ## ======================================================================

  if (use.C) {

    if (!is.loaded("R_dwt_pyramid_up", PACKAGE="dwt"))
    stop("The C function 'R_dwt_pyramid_up' must be dynamically loaded.")
    
    Nj <- length(W)
    z <- double(Nj * 2)
    .C("R_dwt_pyramid_up",
       as.double(V), as.double(W), as.integer(Nj), V = z,
       as.double(filter$scaling), as.double(filter$wavelet),
       as.integer(filter$L),
       PACKAGE="dwt")$V
    
  } else {
    
    V.up <- rev(upsample.by.two(V))
    W.up <- rev(upsample.by.two(W))
    
    rev(circularly.filter(V.up, filter$scaling) +
        circularly.filter(W.up, filter$wavelet))
  }
}



## ======================================================================
## Purpose : Perform a DWT decomposition of the data 'x' to
##           level 'J' using a given 'wavelet'.
## Assumes : Can compose to 'J' levels; i.e., length of 'x' is
##           divisible by 2^J. 
## Requires: C function 'R_dwt_pyramid_down' if use.C=TRUE.
## Updated : pfc@stat.osu.edu, Jun 2002. 
## ======================================================================

dwt <- function (x, wavelet="LA8", J=floor(log2(length(x))), use.C=TRUE)
{
  
  filter <- dwt.filter(wavelet)
  js     <- 1:J
  N      <- length(x)
  Nj     <- N/2^js
  Bj     <- ceiling((filter$L-2)*(1-2^(-js)))
  Lj     <- (2^js-1)*(filter$L-1) + 1 
  V      <- x
  W      <- list(J)
  
  for (j in js)
  {
    results <- dwt.cascade.next(V, filter, use.C)
    V      <- results$V
    W[[j]] <- results$W
  }
  
  structure(list(x=x, W=W, V=V, J=J, N=N, Nj=Nj, Bj=Bj, Lj=Lj,
                 Mj=Nj-Bj, M=N-sum(Bj), filter=filter),
            class="dwt")
}




## ======================================================================
## Purpose : Performs an inverse DWT of the dwt class 'dx'.
## Requires: C function 'R_dwt_pyramid_down' if use.C=TRUE.
## Updated : pfc@stat.washington.edu, Jun 2002.
## ======================================================================

idwt <- function (dx, use.C=TRUE) {
  V <- dx$V  
  for (j in dx$J:1)
    V <- dwt.cascade.previous(V, dx$W[[j]], dx$filter, use.C)
  V
}




## ======================================================================
## Purpose : Updates the dwt object 'dx' with the new data 'x'.
## Assumes : 'x' is of length dx$N.
## Requires: C function 'R_dwt_pyramid_down' if use.C=TRUE.
## Updated : pfc@stat.osu.edu, Aug 2005. 
## ======================================================================

dwt.update <- function (dx, x, use.C=TRUE) {
  
    dx$x <- dx$V <- x
    for (j in 1:dx$J) {
        results <- dwt.cascade.next(dx$V, dx$filter, use.C)
        dx$V <- results$V
        dx$W[[j]] <- results$W
    }
    dx
}



## ======================================================================
## Purpose: Calculates the level 'j' detail coefficients of the DWT
##          object 'dx'.
## Assumes: 1 <= j <= dx$J.
## History: pfc@stat.osu.edu, Jul 2002.
## ======================================================================

dwt.detail <- function (dx, j)
{
  dz   <- dwt.zero(dx, seq(dx$J)[-j])
  dz$V <- dz$V * 0
  idwt(dz)
}




## ======================================================================
## Purpose: Calculates the level 'j' smooth coefficients of the DWT
##          object 'dx'.
## Assumes: 1 <= j <= dx$J.
## History: pfc@stat.osu.edu, Jul 2002.
## ======================================================================

dwt.smooth <- function (dx, j)
{
  idwt(dwt.zero(dx, 1:j))
}





## ======================================================================
## Purpose : returns the level 'j' non-boundary (nb) wavelet
##           coefficients of the dwt class 'dx'.
## Assumes : 1 <= j <= dx$J.
## Updated : pfc@stat.osu.edu, Oct 2001. 
## ======================================================================

dwt.nb <- function (dx, j)
{
  dx$W[[j]][(dx$Bj[j]+1):dx$Nj[j]]
}





## ======================================================================
## Purpose : returns the sum of squares of the level 'j' 
##           wavelet coefficients of the dwt class 'dx'.
## Assumes : 1 <= j <= dx$J.
## Updated : pfc@stat.osu.edu, Oct 2001. 
## ======================================================================

dwt.sumsq <- function (dx, from=dx$Bj+1, to=dx$Nj)
{
  sapply(1:dx$J, function (j, W, from, to)
         sum(W[[j]][from[j]:to[j]]^2), W=dx$W, from=from, to=to)
}




## ======================================================================
## Purpose: Calculates the either the unbiased or biased wavelet
##          sample variance based on the DWT object 'dx'.
##          (equation (308a) or equation (308b) of Percival and
##           Walden (2000)).
## History: pfc@stat.osu.edu, Apr 2002.
## ======================================================================

dwt.var <- function (dx, biased=FALSE)
{
  if (biased)
    dwt.sumsq(dx, rep(1,dx$J))/dx$N
  else
    dwt.sumsq(dx)/(2^seq(dx$J) * dx$Nj)
}





## ======================================================================
## Purpose : zero out levels 'js' of the dwt class 'dx', between
##           indexes 'from[j]' and 'to[j]'.
## Defaults: js = 1:dx$J, from = 1, to = dx$Nj[j].
## Updated : pfc@stat.osu.edu, Oct 2001. 
## ======================================================================

dwt.zero <- function (dx, js=seq(dx$J),
                      from=rep(1,length(js)), to=dx$Nj[js])
{
  for (j in 1:length(js))
    dx$W[[js[j]]][from[j]:to[j]] <- 0
  dx
}



