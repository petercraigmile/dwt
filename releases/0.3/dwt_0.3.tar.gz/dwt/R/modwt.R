## ======================================================================
## File     : modwt.R
## Purpose  : R code for the Maximum Overlap Discrete Wavelet
##            Transform (MODWT).
## Requires : (1) The C functions
##                  "R_modwt_pyramid_down", "R_modwt_pyramid_down",
##                  "R_sqgain", "R_dwt_Daub_sqgain"
##                to be dynamically loaded.
##            (2) dwt.R
## Updated  : pfc@stat.ohio-state.edu, Apr 2005. 
## 
## Copyright 2002--2005, Peter F. Craigmile, All Rights Reserved
## Address comments about this software to pfc@stat.ohio-state.edu.
##
## The use of this software is permitted for academic purposes only,
## provided its use is acknowledged.  Commercial use is not allowed
## without the permission of the author.  This software is made available
## AS IS, and no warranty -- about the software, its performance, or
## its conformity to any specification -- is given or implied.
## ======================================================================


modwt.down <- function (prev.V, j, filter)
{
  N <- length(prev.V)
  z <- double(N)
  .C("R_modwt_pyramid_down",
     as.double(prev.V), as.integer(N), as.integer(j), V = z, W = z,
     as.double(filter$g), as.double(filter$h), as.integer(filter$L),
     PACKAGE="dwt")
}





## ======================================================================
## Purpose : Perform a MODWT decomposition of the data 'x' to
##           level 'J' using a given 'wavelet'.
## Updated : pfc@stat.ohio-state.edu, June 2002. 
## ======================================================================

modwt <- function (x, wavelet="LA8", J)
{
  if (!is.loaded("R_modwt_pyramid_down"))
    stop("The C function 'R_modwt_pyramid_down' must be dynamically loaded.")
  
  filter   <- modwt.filter(wavelet)
  js       <- 1:J
  N        <- length(x)
  Lj       <- (2^js-1)*(filter$L-1)+1
  Bj       <- Lj-1
  Bj[Bj>N] <- N
    
  V        <- x
  W        <- list(J)
  z        <- double(N)

  for (j in js)
  {
    results <- modwt.down(V, j, filter)
    V       <- results$V
    W[[j]]  <- results$W
  }
  
  structure(list(x=x, W=W, V=V, J=J, N=N, Lj=Lj, Mj=N-Lj+1, Bj=Bj,
                 filter=filter), class="modwt")
}




## ======================================================================
## Purpose : Performs an inverse MODWT of the dwt class 'dx'.
## Updated : pfc@stat.washington.edu, June 2002.
## ======================================================================

imodwt <- function (dx)
{
  if (!is.loaded("R_modwt_pyramid_up"))
    stop("The C function 'R_modwt_pyramid_up' must be dynamically loaded.")

  V <- dx$V
  z <- double(dx$N)
  
  for (j in dx$J:1)
    V <- .C("R_modwt_pyramid_up",
            as.double(V), as.double(dx$W[[j]]), as.integer(dx$N),
            as.integer(j), V = z,
            as.double(dx$filter$g), as.double(dx$filter$h),
            as.integer(dx$filter$L), PACKAGE="dwt")$V
  
  V
}



## ======================================================================
## Purpose : Update the MODWT object 'dx' with the new data 'x'.
## Assumes : 'x' is of length dx$N.
## Updated : pfc@stat.ohio-state.edu, August 2005.
## ======================================================================

modwt.update <- function (dx, x)
{
  if (!is.loaded("R_modwt_pyramid_down"))
    stop("The C function 'R_dwt_pyramid_down' must be dynamically loaded.")

  z      <- double(dx$N)
  dx$V   <- x
  
  for (j in 1:dx$J)
  {
    results <- modwt.down(dx$V, j, dx$filter)
    dx$V      <- results$V
    dx$W[[j]] <- results$W
  }

  dx
}



## ======================================================================
## Purpose : returns the level 'j' non-boundary (nb) wavelet
##           coefficients of the modwt class 'dx'.
## Assumes : 1 <= j <= dx$J.
## Updated : pfc@stat.ohio-state.edu, October 2001. 
## ======================================================================

modwt.nb <- function (dx, j)
{
  dx$W[[j]][(dx$Bj[j]+1):dx$N]
}





## ======================================================================
## Purpose: Calculates the level 'j' detail coefficients of the MODWT
##          object 'dx'.
## Assumes: 1 <= j <= dx$J.
## History: pfc@stat.ohio-state.edu, Apr 2005.
## ======================================================================

modwt.detail <- function (dx, j)
{
  dz   <- modwt.zero(dx, seq(dx$J)[-j])
  dz$V <- dz$V * 0
  imodwt(dz)
}






## ======================================================================
## Purpose: Calculates the level 'j' smooth coefficients of the MODWT
##          object 'dx'.
## Assumes: 1 <= j <= dx$J.
## History: pfc@stat.ohio-state.edu, Apr 2005.
## ======================================================================

modwt.smooth <- function (dx, j)
{
  imodwt(modwt.zero(dx, 1:j))
}





## ======================================================================
## Purpose : zero out levels 'js' of the modwt class 'dx', between
##           indexes 'from[j]' and 'to[j]'.
## Defaults: js = 1:dx$J, from = 1, to = dx$Nj[j].
## Updated : pfc@stat.ohio-state.edu, Apr 2005.
## ======================================================================

modwt.zero <- function (dx, js=seq(dx$J),
                        from=rep(1,length(js)), to=rep(dx$N, length(js)))
{
  for (j in 1:length(js))
    dx$W[[js[j]]][from[j]:to[j]] <- 0
  dx
}



## ===================================================================
## Purpose : Returns the approximate bandpass frequencies for the
##           level 'js' wavelet coefficients of the modwt class 'dx'.
## Updated : pfc@stat.ohio-state.edu, Apr 2005.
## ===================================================================

modwt.freqs <- function (dx, js)
{
  outer(c(0.5,1)/deltat(dx$x), 2^(-js))
}





## ===================================================================
## Purpose : Returns a vector of the times associated with the
##           scaling (is.wavelet=F) or wavelet (is.wavelet=T)
##           coefficients for level 'j' of the MODWT object 'dx'. 
## Updated : pfc@stat.ohio-state.edu, June 2002.
## ===================================================================

modwt.times <- function (dx, j, is.wavelet=T)
{
  start <- (sum(start(dx$x))-1)/frequency(dx$x)
  vj    <- dwt.filter.vj(dx$filter, j, is.wavelet)
  rotate.vector(seq(from=start, by=deltat(dx$x), length=dx$N), abs(vj))
}





## ======================================================================
## Purpose: Calculates either the unbiased or biased sample
##          wavelet variance based on the MODWT object 'dx'.
##          (equation (306b) or equation (306c) of Percival and
##           Walden (2000)).
## History: pfc@stat.ohio-state.edu, April 2002.
## ======================================================================

modwt.var <- function (dx, biased=F)
{
  vars <- rep(0,dx$J)
  if (biased)
    for (j in 1:dx$J)
      vars[j] <- mean(dx$W[[j]]^2)
  else
    for (j in 1:dx$J)
      vars[j] <- mean(dx$W[[j]][dx$Lj[j]:dx$N]^2)

  vars
}



## ======================================================================
## Purpose: MODWT variance -- NEEDS DOCUMENTATION.
## History: pfc@stat.ohio-state.edu, May 2002.
## ======================================================================

modwt.var.ci <- function (dx, vars, alpha=0.05)
  ## need to add a 'method=3' parameter
{
#  if (method==1) ## use equation (313d) and page 312.
#  {
    ## to implement
    ##Aj.hat <- vars^2/2 + sum(acvs for level j)
    ##etas <- dx$Mj * vars^2 / Aj.hat
#  }
#  else if (method==2) ## use equation (313b)
#  {
    ## to implement
#  }
#  else ## use equation (313c)
  etas <- max(dx$Mj/2^seq(dx$J),1)
  
  lower <- etas * vars / qchisq(1-alpha/2,1)
  upper <- etas * vars / qchisq(alpha/2,1)

  list(vars=vars, lower=lower, upper=upper)
}





## ======================================================================
## Purpose : Creates a rotated cumulative variance plot of the MODWT
##           object 'dx', level 'j', as explained on page 189 of Percival
##           and Walden (2000).
## Updated : pfc@stat.ohio-state.edu, June 2002.
## ======================================================================

modwt.cumvar.plot <- function (dx, j, xlab="time", ylab="", ...)
{
  vj <- dwt.filter.vj(dx$filter, j, T)
 
  ## rotate the MODWT wavelet coefficients and take squares
  Cj       <- cumsum(rotate.vector(dx$W[[j]], -abs(vj))^2 / dx$N)

  ## adjust the value of Cj
  Cj.prime <- Cj - seq(0:(dx$N-1)) * Cj[dx$N]/(dx$N-1)

  start <- (sum(start(dx$x))-1)/frequency(dx$x)
  ts    <- seq(from=start, by=deltat(dx$x), length=dx$N)
  
  plot(ts, Cj.prime, type="l", xlab=xlab, ylab=ylab, ...)
}






## ===================================================================
## Purpose : to produce a wavelet decomposition plot of the MODWT
##           class 'dx' using a stacked plot.
## Updated : pfc@stat.washington.edu, April 2002.
## ===================================================================

plot.modwt <- function (x, xlab="time", col="black", 
		        bg="white", bdcol="blue", ...) 
{
  xs <- ys <- vlines <- list()
  ys         <- list()
  start      <- (sum(start(x$x))-1)/frequency(x$x)
  ts         <- seq(from=start, length=x$N, by=deltat(x$x))
  xlabels    <- rep("",x$J+2)
  types      <- c("l", rep("l",x$J), "l")
  xs[[1]]    <- ts
  ys[[1]]    <- x$x
  xlabels[1] <- "X"
  vn         <- 0

  for (j in 1:x$J)
  {
    ks           <- modwt.times(x, j, T)
    xs[[j+1]]    <- sort(ks)
    ys[[j+1]]    <- x$W[[j]][order(ks)]
    xlabels[j+1] <- paste("W", j, sep="")

    if (x$Bj[j]>0)
    {
      delta <- diff(ks)[1]/2
      vlines[[vn+1]] <- c(j,ks[1]  - delta)
      vlines[[vn+2]] <- c(j,ks[x$Bj[j]] + delta)
      vn <- vn + 2
    }
  }

  ks                <- modwt.times(x, x$J, F)
  xs[[x$J+2]]      <- sort(ks)
  ys[[x$J+2]]      <- x$V[order(ks)]
  xlabels[[x$J+2]] <- paste("V",x$J, sep="")

  if (x$Bj[x$J]>0)
  {
    delta <- diff(ks)[1]/2
    vlines[[vn+1]] <- c(x$J+1,ks[1]  - delta)
    vlines[[vn+2]] <- c(x$J+1,ks[x$Bj[x$J]] + delta)
    vn <- vn + 2
  }
  
  stackplot(xs, ys, ts, xlabels, types, vlines, xlab=xlab,
            col=col, bg=bg, bdcol=bdcol, ...)
}





## ===========================================================================
## Purpose : ** TO WRITE **
## Updated : pfc@stat.ohio-state.edu, Aug 2002.
## ===========================================================================

modwt.acvs.from.sdf <- function (J, max.lag, filter, sdf.fun, wavelet=T, ...)
{
  if (!exists("dwt.acvs.gw"))
    dwt.acvs.gw <<- Gauss.weights(0, 0.5, 128)
  
  fs <- dwt.acvs.gw$absc
  z  <- as.double(2 * dwt.acvs.gw$wghts * sdf.fun(fs, ...))
  
  matrix(.C("R_modwt_acvs",
            acvs = as.double(rep(0,J*(max.lag+1))),
            as.integer(J), as.integer(max.lag),
            z, z, as.double(fs),
            as.integer(dwt.acvs.gw$length),
            as.integer(wavelet), as.double(filter$g*sqrt(2)),
            as.integer(filter$L), PACKAGE="dwt")$acvs, max.lag+1)
}




## ======================================================================
## Purpose : Perform a packet MODWT decomposition of the data 'x' to
##           level 'J' using a given 'wavelet'.
## Updated : pfc@stat.ohio-state.edu, June 2002. 
## ======================================================================

packet.modwt <- function (x, wavelet, J)
{
  if (!is.loaded("R_modwt_pyramid_down", PACKAGE="dwt"))
    stop("The C function 'R_modwt_pyramid_down' must be dynamically loaded.")
  
  filter   <- modwt.filter(wavelet)
  N        <- length(x)
  js       <- 1:J
  lamj     <- 2^js
  Lj       <- (lamj-1)*(filter$L-1)+1
  Bj       <- Lj-1
  Bj[Bj>N] <- N
  W        <- list(J)  
  results  <- modwt.down(x, 1, filter)
  W[[1]]   <- list(results$V, results$W)

  if (J>1)
    for (j in 2:J)
    {
      W.prev <- W[[j-1]]
      W[[j]] <- list(lamj[j])
      m      <- 1
      for (n in 1:lamj[j-1])
      {
        results <- modwt.down(W.prev[[n]], j, filter)
        if (n%%2==1)
        {
          W[[j]][[m]]   <- results$V
          W[[j]][[m+1]] <- results$W
        }
        else
        {
          W[[j]][[m]]   <- results$W
          W[[j]][[m+1]] <- results$V
        }
        m <- m + 2
      }
    }
  
  structure(list(x=x, W=W, J=J, N=N, lamj=lamj, Bj=Bj, Lj=Lj,
                 Mj=Lj+1, filter=filter), class="modwpt")
}


## ======================================================================
## Purpose: show the sequence of filter operations to get to W_{j,n}
##          using the packet hilbert modwt transform.
## ======================================================================

packet.modwt.sequence <- function (j, n)
{
  nn <- n-1
  cs <- NULL
  for (k in j:1)
  {
    if ((nn%%4==0) || (nn%%4==3))
      cs <- c(0, cs)
    else
      cs <- c(1, cs)
    nn <- floor(nn / 2)
  }
  cs
}


packet.modwt.custom <- function (x, filter, j, n, phase.shift=F)
{
  cs <- packet.modwt.sequence(j, n)
  V <- x
  for (j in 1:length(cs))
  {

    results <- modwt.down(V, j, filter)
    if (cs[j])
      V <- results$W
    else
      V <- results$V
  }

  if (phase.shift)
    rotate.vector(V, -abs(packet.modwt.time.shifts(j, n, filter)))
  else
    V
}

