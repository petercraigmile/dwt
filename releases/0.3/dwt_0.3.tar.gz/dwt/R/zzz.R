.First.lib <- function(lib, pkg) library.dynam('dwt', pkg, lib)
