
hilbert.dwt.down <- function (prev.V, j, filter)
{
  z <- double(length(prev.V)/2)
  N <- length(prev.V)

  if (j==1)
    prev.V <- complex(real=prev.V, imag=prev.V)

  filter.a <- .C("R_dwt_pyramid_down",
                 as.double(Re(prev.V)), as.integer(length(prev.V)), 
                 V = z, W = z,
                 as.double(filter$a0), as.double(filter$a1), 
                 as.integer(filter$L), PACKAGE = "dwt")

  filter.b <- .C("R_dwt_pyramid_down",
                 as.double(Im(prev.V)), as.integer(length(prev.V)), 
                 V = z, W = z,
                 as.double(filter$b0), as.double(filter$b1), 
                 as.integer(filter$L), PACKAGE = "dwt")

  list(V = complex(real=filter.a$V, imag=filter.b$V),
       W = complex(real=filter.a$W, imag=filter.b$W))
}



hilbert.modwt.down <- function (prev.V, j, filter)
{
  N <- length(prev.V)
  z <- double(N)

  if (j==1)
    prev.V <- complex(real=prev.V, imag=prev.V)

  filter.a <- .C("R_modwt_pyramid_down",
                 as.double(Re(prev.V)), as.integer(N), 
                 as.integer(j), V = z, W = z,
                 as.double(filter$a0), as.double(filter$a1), 
                 as.integer(filter$L), PACKAGE = "dwt")

  filter.b <- .C("R_modwt_pyramid_down",
                 as.double(Im(prev.V)), as.integer(N), 
                 as.integer(j), V = z, W = z,
                 as.double(filter$b0), as.double(filter$b1), 
                 as.integer(filter$L), PACKAGE = "dwt")


  list(V = complex(real=filter.a$V, imag=filter.b$V),
       W = complex(real=filter.a$W, imag=filter.b$W))
}





hilbert.modwt <- function (x, filter, J)
{
  if (!is.loaded("R_modwt_pyramid_down", PACKAGE="dwt"))
    stop("The C function 'R_modwt_pyramid_down' must be dynamically loaded.")

  js <- seq(J)
  N <- length(x)
  Lj <- (2^js - 1) * (filter$L - 1) + 1
  Bj <- Lj - 1
  Bj[Bj > N] <- N
  V <- x
  W <- list(J)

  z <- double(N)
  for (j in js)
  {
    results <- hilbert.modwt.down(V, j, filter)
    V       <- results$V
    W[[j]]  <- results$W
  }

  structure(list(x=x, W=W, V=V, J=J, N=N,
                 Lj=Lj, Mj=N-Lj+1, Bj=Bj, filter=filter), class="hilbert")  
}


center.of.energy <- function (x)
{
  sum((1:(length(x)-1))*x[-1]^2)/sum(x^2)
}


hilbert.modwt.time.shifts <- function (js, filter, is.wavelet=T)
{
  ea0 <- center.of.energy(filter$a0)
  if (is.wavelet)
  {
    ea1 <- center.of.energy(filter$a1)
    round(2^(js-1) * (ea0 + ea1) - ea0)
  }
  else
    round((2^js - 1) * ea0)
}


hilbert.modwt.Sx <- function (dx, j=NULL, is.wavelet=T)
{
  if (is.wavelet)
      x <- Mod(dx$W[[j]])^2
  else
  {
    j <- dx$J
    x <- Mod(dx$V)^2
  }
  Re(rotate.vector(x, -hilbert.modwt.time.shifts(j, dx$filter, is.wavelet)))
}



hilbert.modwt.Sxy <- function (dx, dy, j=NULL, is.wavelet=T)
{
  if (is.wavelet)
    x <- dx$W[[j]]*Conj(dy$W[[j]])
  else
  {
    j <- dx$J
    x <- dx$V*Conj(dy$V)
  }
  rotate.vector(x, -hilbert.modwt.time.shifts(j, dx$filter, is.wavelet))
}

hilbert.modwt.Axy <- function (dx, dy, j=NULL, is.wavelet=T)
{
  Mod(hilbert.modwt.Sxy(dx, dy, j, is.wavelet))
}

hilbert.modwt.Cxy <- function (dx, dy, j=NULL, is.wavelet=T)
{
  Re(hilbert.modwt.Sxy(dx, dy, j, is.wavelet))
}

hilbert.modwt.Qxy <- function (dx, dy, j=NULL, is.wavelet=T)
{
  -Im(hilbert.modwt.Sxy(dx, dy, j, is.wavelet))
}

hilbert.modwt.MSC <- function (dx, dy, j=NULL, is.wavelet=T, M)
{
  fs <- rep(1, M)/M
  Axy2 <- filter(hilbert.modwt.Axy(dx, dy, j, is.wavelet)^2, fs, circular=F)
  Sx <- filter(hilbert.modwt.Sx(dx, j, is.wavelet), fs, circular=F)
  Sy <- filter(hilbert.modwt.Sx(dy, j, is.wavelet), fs, circular=F)
  Axy2 / (Sx * Sy)
}


hilbert.modwt.rotate <- function (dx)
{
  for (j in 1:dx$J)
    dx$W[[j]] <- rotate.vector(dx$W[[j]],
                               -hilbert.modwt.time.shifts(j, dx$filter, T))
  dx$V <- rotate.vector(dx$V,
                        -hilbert.modwt.time.shifts(dx$J, dx$filter, F))
  dx
}



## ======================================================================
## Purpose : Perform a HDWPT decomposition of the data 'x' to
##           level 'J' using a given 'wavelet'.
## Updated : pfc@stat.ohio-state.edu, June 2002. 
## ======================================================================

dhwpt <- function (x, filter, J)
{
  if (!is.loaded("R_dwt_pyramid_down", PACKAGE="dwt"))
    stop("The C function 'R_dwt_pyramid_down' must be dynamically loaded.")
  
  N        <- length(x)
  js       <- 1:J
  lamj     <- 2^js
  N        <- length(x)
  Nj       <- N/lamj
  Bj       <- ceiling((filter$L-2)*(1-2^(-js)))
  Lj       <- (2^js-1)*(filter$L-1) + 1 
  W        <- list(J)  
  results  <- dhwt.down(x, 1, filter)
  W[[1]]   <- list(results$V, results$W)

  if (J>1)
    for (j in 2:J)
    {
      W.prev <- W[[j-1]]
      W[[j]] <- list(lamj[j])
      m      <- 1
      for (n in 1:lamj[j-1])
      {
        results <- dhwt.down(W.prev[[n]], j, filter)
        if (n%%2==1)
        {
          W[[j]][[m]]   <- results$V
          W[[j]][[m+1]] <- results$W
        }
        else
        {
          W[[j]][[m]]   <- results$W
          W[[j]][[m+1]] <- results$V
        }
        m <- m + 2
      }
    }
  
  structure(list(x=x, W=W, J=J, N=N, Nj=Nj, lamj=lamj, Bj=Bj, Lj=Lj,
                 Mj=Lj+1, filter=filter), class="dhwpt")
}




## ======================================================================
## Purpose : Perform a MOHDWPT decomposition of the data 'x' to
##           level 'J' using a given 'wavelet'.
## Updated : pfc@stat.ohio-state.edu, June 2002. 
## ======================================================================

packet.hilbert.modwt <- function (x, filter, J)
{
  if (!is.loaded("R_modwt_pyramid_down", PACKAGE="dwt"))
    stop("The C function 'R_modwt_pyramid_down' must be dynamically loaded.")
  
  N        <- length(x)
  js       <- 1:J
  lamj     <- 2^js
  Lj       <- (lamj-1)*(filter$L-1)+1
  Bj       <- Lj-1
  Bj[Bj>N] <- N
  W        <- list(J)  
  results  <- hilbert.modwt.down(x, 1, filter)
  W[[1]]   <- list(results$V, results$W)

  if (J>1)
    for (j in 2:J)
    {
      W.prev <- W[[j-1]]
      W[[j]] <- list(lamj[j])
      m      <- 1
      for (n in 1:lamj[j-1])
      {
        results <- hilbert.modwt.down(W.prev[[n]], j, filter)
        if (n%%2==1)
        {
          W[[j]][[m]]   <- results$V
          W[[j]][[m+1]] <- results$W
        }
        else
        {
          W[[j]][[m]]   <- results$W
          W[[j]][[m+1]] <- results$V
        }
        m <- m + 2
      }
    }
  
  structure(list(x=x, W=W, J=J, N=N, lamj=lamj, Bj=Bj, Lj=Lj,
                 Mj=Lj+1, filter=filter), class="packet.hilbert.modwt")
}


packet.hilbert.modwt.freqs <- function (j, n, deltat=1)
{
  c(n-1,n)/(2^(j+1) * deltat)
}



packet.hilbert.modwt.time.shifts <- function (j, n, filter)
{
  ea0 <- center.of.energy(filter$a0)
  ea1 <- center.of.energy(filter$a1)

  cs <- packet.hilbert.modwt.sequence(j, n)
  eps <- sum(cs * 2^(0 : (j-1)))
  round((2^j-1-eps) * ea0 + eps * ea1)
}



## ======================================================================
## Purpose: show the sequence of filter operations to get to W_{j,n}
##          using the packet hilbert modwt transform.
## ======================================================================

packet.hilbert.modwt.sequence <- function (j, n)
{
  nn <- n-1
  cs <- NULL
  for (k in j:1)
  {
    if ((nn%%4==0) || (nn%%4==3))
      cs <- c(0, cs)
    else
      cs <- c(1, cs)
    nn <- floor(nn / 2)
  }
  cs
}


packet.hilbert.modwt.custom <- function (x, filter, j, n, phase.shift=F)
{
  cs <- packet.hilbert.modwt.sequence(j, n)
  V <- x
  for (j in 1:length(cs))
  {

    results <- hilbert.modwt.down(V, j, filter)
    if (cs[j])
      V <- results$W
    else
      V <- results$V
  }

  if (phase.shift)
    rotate.vector(V, -abs(packet.hilbert.modwt.time.shifts(j, n, filter)))
  else
    V
}

