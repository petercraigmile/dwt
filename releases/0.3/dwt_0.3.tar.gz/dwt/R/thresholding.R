




dwt.threshold <- function (dx, hard=T, min.J=0)
{
  sigma <- mad(dx$W[[1]])
  delta <- universal.threshold(sigma^2, dx$N)

  if (hard)
  {
    for (j in (min.J+1):dx$J)
      dx$W[[j]] <- hard.threshold(dx$W[[j]], delta)
    if (min.J!=0)
      for (j in 1:min.J) dx$W[[j]] <- dx$W[[j]] * 0
  }
  else
    {
    for (j in (min.J+1):dx$J)
      dx$W[[j]] <- soft.threshold(dx$W[[j]], delta)
    if (min.J!=0)
      for (j in 1:min.J) dx$W[[j]] <- dx$W[[j]] * 0
  }

  list(dx=dx, x=idwt(dx), sigma=sigma)
}



## WMTSA, equation (399)
hard.threshold <- function (x, delta)
{
  ifelse(abs(x) < delta, 0, x)
}


## WMTSA, equation (400a)
soft.threshold <- function (x, delta)
{
  z <- abs(x) - delta
  sign(x) * ifelse(z>0, z, 0)
}


## WMTSA, equation (400d)
universal.threshold <- function (sigma.sq, N)
{
  sqrt(2 * sigma.sq * log(N))
}


## WMTSA, equation (400d)
sure.objective.value <- function (delta, x, sigma.sq.0)
{
  sum((2 * sigma.sq.0 - x^2 + delta)[delta^2 > x^2])
}


## WMTSA, equation (406a)
sure.threshold <- function (x, sigma.sq.0=mad(x))
{
  optimize(sure.threshold.value, x=x, sigma.sq.0=sigma.sq.0)
}



