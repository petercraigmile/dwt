
packet.dwt <- function (x, wavelet, J)
{
  if (!is.loaded("R_dwt_pyramid_down", PACKAGE="dwt"))
    stop("The C function 'R_dwt_pyramid_down' must be dynamically loaded.")
  
  filter  <- dwt.filter(wavelet)
  N       <- length(x)
  js      <- 1:J
  lamj    <- 2^js
  Nj      <- N/lamj
  Lj      <- (lamj-1)*(filter$L-1) + 1
  Bj      <- ceiling((filter$L-2)*(1-2^(-js)))
  W       <- list(J)
  results <- dwt.down(x, filter)
  W[[1]]  <- list(results$V, results$W)

  if (J>1)
    for (j in 2:J)
    {
      W.prev <- W[[j-1]]
      W[[j]] <- list(lamj[j])
      m      <- 1
      for (n in 1:lamj[j-1])
      {
        results <- dwt.down(W.prev[[n]], filter)
        if (n%%2==1)
        {
          W[[j]][[m]]   <- results$V
          W[[j]][[m+1]] <- results$W
        }
        else
        {
          W[[j]][[m]]   <- results$W
          W[[j]][[m+1]] <- results$V
        }
        m <- m + 2
      }
    }
  
  structure(list(x=x, W=W, J=J, N=N, lamj=lamj, Nj=Nj, Bj=Bj, Lj=Lj,
                 Mj=Nj-Bj, M=N-sum(Bj), filter=filter), class="packet.dwt")
}

