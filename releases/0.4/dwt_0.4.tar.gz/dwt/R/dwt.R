## ======================================================================
## File     : dwt.R
## Purpose  : R code for the Discrete Wavelet Transform (DWT).
## Requires : (1) The C functions "R_dwt_pyramid_down",
##                "R_dwt_pyramid_up" to be dynamically loaded.
##            (2) stackplot.R, Gauss_rule.R
## Updated  : pfc@stat.ohio-state.edu, Sep 2008.
## 
## Copyright 2002--2008, Peter F. Craigmile, All Rights Reserved
## Address comments about this software to pfc@stat.ohio-state.edu.
##
## The use of this software is permitted for academic purposes only,
## provided its use is acknowledged.  Commercial use is not allowed
## without the permission of the author.  This software is made available
## AS IS, and no warranty -- about the software, its performance, or
## its conformity to any specification -- is given or implied.
## ======================================================================


dwt.down <- function (prev.V, filter)
{
  z <- double(length(prev.V)/2)
  results <- .C("R_dwt_pyramid_down",
                as.double(prev.V), as.integer(length(prev.V)),
                V = z, W = z,
                as.double(filter$g), as.double(filter$h), as.integer(filter$L),
                PACKAGE="dwt")
}

dwt.up <- function (V, W, filter)
{
  Nj <- length(W)
  z <- double(Nj * 2)
  .C("R_dwt_pyramid_up",
     as.double(V), as.double(W), as.integer(Nj), V = z,
     as.double(filter$g), as.double(filter$h), as.integer(filter$L),
     PACKAGE="dwt")$V
}


## ======================================================================
## Purpose : Perform a DWT decomposition of the data 'x' to
##           level 'J' using a given 'wavelet'.
## Assumes : Can compose to 'J' levels; i.e., length of 'x' is
##           divisible by 2^J. 
## Requires: C function 'R_dwt_pyramid_down'.
## Updated : pfc@stat.ohio-state.edu, Jun 2002. 
## ======================================================================

dwt <- function (x, wavelet="LA8", J=floor(log2(length(x))))
{
  if (!is.loaded("R_dwt_pyramid_down", PACKAGE="dwt"))
    stop("The C function 'R_dwt_pyramid_down' must be dynamically loaded.")
  
  filter <- dwt.filter(wavelet)
  js     <- 1:J
  N      <- length(x)
  Nj     <- N/2^js
  Bj     <- ceiling((filter$L-2)*(1-2^(-js)))
  Lj     <- (2^js-1)*(filter$L-1) + 1 
  V      <- x
  W      <- list(J)
  
  for (j in js)
  {
    results <- dwt.down(V, filter)
    V      <- results$V
    W[[j]] <- results$W
  }
  
  structure(list(x=x, W=W, V=V, J=J, N=N, Nj=Nj, Bj=Bj, Lj=Lj,
                 Mj=Nj-Bj, M=N-sum(Bj), filter=filter),
            class="dwt")
}




## ======================================================================
## Purpose : Performs an inverse DWT of the dwt class 'dx'.
## Requires: C function 'R_dwt_pyramid_up'.
## Updated : pfc@stat.washington.edu, Jun 2002.
## ======================================================================

idwt <- function (dx)
{
  if (!is.loaded("R_dwt_pyramid_up", PACKAGE="dwt"))
    stop("The C function 'R_dwt_pyramid_up' must be dynamically loaded.")

  V <- dx$V  
  for (j in dx$J:1)
    V <- dwt.up(V, dx$W[[j]], dx$filter)
  V
}




## ======================================================================
## Purpose : Updates the dwt object 'dx' with the new data 'x'.
## Assumes : 'x' is of length dx$N.
## Requires: C function 'R_dwt_pyramid_down'.
## Updated : pfc@stat.ohio-state.edu, Aug 2005. 
## ======================================================================

dwt.update <- function (dx, x) 
{
    if (!is.loaded("R_dwt_pyramid_down", PACKAGE = "dwt")) 
        stop("The C function 'R_dwt_pyramid_down' must be dynamically loaded")
    dx$x <- dx$V <- x
    for (j in 1:dx$J) {
        results <- dwt.down(dx$V, dx$filter)
        dx$V <- results$V
        dx$W[[j]] <- results$W
    }
    dx
}



## ======================================================================
## Purpose: Calculates the level 'j' detail coefficients of the DWT
##          object 'dx'.
## Assumes: 1 <= j <= dx$J.
## History: pfc@stat.ohio-state.edu, Jul 2002.
## ======================================================================

dwt.detail <- function (dx, j)
{
  dz   <- dwt.zero(dx, seq(dx$J)[-j])
  dz$V <- dz$V * 0
  idwt(dz)
}




## ======================================================================
## Purpose: Calculates the level 'j' smooth coefficients of the DWT
##          object 'dx'.
## Assumes: 1 <= j <= dx$J.
## History: pfc@stat.ohio-state.edu, Jul 2002.
## ======================================================================

dwt.smooth <- function (dx, j)
{
  idwt(dwt.zero(dx, 1:j))
}




## ===================================================================
## Purpose : Returns a vector of the times associated with the
##           scaling (is.wavelet=F) or wavelet (is.wavelet=T)
##           coefficients for level 'j' of the DWT object 'dx'. 
## Updated : pfc@stat.ohio-state.edu, Jun 2002.
## ===================================================================

dwt.times <- function (dx, j, is.wavelet=T)
{
  start <- start(dx$x)[1] + (start(dx$x)[2]-1)/frequency(dx$x)
  vj    <- dwt.filter.vj(dx$filter, j, is.wavelet)
  start + deltat(dx$x) * ((2^j*(seq(dx$Nj[j])) - 1 - abs(vj)) %% dx$N)
}




## ===================================================================
## Purpose : Returns the approximate bandpass frequencies for the
##           level 'js' wavelet coefficients of the dwt class 'dx'.
## Updated : pfc@stat.ohio-state.edu, Jun 2002.
## ===================================================================

dwt.freqs <- function (dx, js)
{
  outer(c(0.5,1)/deltat(dx$x), 2^(-js))
}




## ======================================================================
## Purpose : returns the level 'j' non-boundary (nb) wavelet
##           coefficients of the dwt class 'dx'.
## Assumes : 1 <= j <= dx$J.
## Updated : pfc@stat.ohio-state.edu, Oct 2001. 
## ======================================================================

dwt.nb <- function (dx, j)
{
  dx$W[[j]][(dx$Bj[j]+1):dx$Nj[j]]
}





## ======================================================================
## Purpose : returns the sum of squares of the level 'j' 
##           wavelet coefficients of the dwt class 'dx'.
## Assumes : 1 <= j <= dx$J.
## Updated : pfc@stat.ohio-state.edu, Oct 2001. 
## ======================================================================

dwt.sumsq <- function (dx, from=dx$Bj+1, to=dx$Nj)
{
  sapply(1:dx$J, function (j, W, from, to)
         sum(W[[j]][from[j]:to[j]]^2), W=dx$W, from=from, to=to)
}




## ======================================================================
## Purpose: Calculates the either the unbiased or biased wavelet
##          sample variance based on the DWT object 'dx'.
##          (equation (308a) or equation (308b) of Percival and
##           Walden (2000)).
## History: pfc@stat.ohio-state.edu, Apr 2002.
## ======================================================================

dwt.var <- function (dx, biased=F)
{
  if (biased)
    dwt.sumsq(dx, rep(1,dx$J))/dx$N
  else
    dwt.sumsq(dx)/(2^seq(dx$J) * dx$Nj)
}





## ======================================================================
## Purpose : zero out levels 'js' of the dwt class 'dx', between
##           indexes 'from[j]' and 'to[j]'.
## Defaults: js = 1:dx$J, from = 1, to = dx$Nj[j].
## Updated : pfc@stat.ohio-state.edu, Oct 2001. 
## ======================================================================

dwt.zero <- function (dx, js=seq(dx$J),
                      from=rep(1,length(js)), to=dx$Nj[js])
{
  for (j in 1:length(js))
    dx$W[[js[j]]][from[j]:to[j]] <- 0
  dx
}




## ======================================================================
## Purpose : Calculate the wavelet transform matrix for the dwt
##           object 'dx'.
## Updated : pfc@stat.ohio-state.edu, Oct 2001. 
## ======================================================================

dwt.matrix <- function (dx)
{
  dz <- dwt.update(dx, rep(0, dx$N))
  W  <- matrix(0, dx$N, dx$N)
  r  <- 1
  
  for (j in 1:dx$J)
    for (k in 1:dx$Nj[j])
    {
      dz$W[[j]][k] <- 1
      W[r,]        <- idwt(dz)
      dz$W[[j]][k] <- 0
      r            <- r + 1
    }

  for (k in 1:dx$Nj[dx$J])
  {
    dz$V[k] <- 1
    W[r,]   <- idwt(dz)
    dz$V[k] <- 0
    r       <- r + 1
  }

  W	
}




## ======================================================================
## Purpose : Calculate a subset of wavelet transform matrix for the dwt
##           object 'dx'.  Only include the rows corresponding
##           to the first wavelet coefficient per level, and the first
##           level dx$J scaling coefficient.
## Updated : pfc@stat.ohio-state.edu, Oct 2001. 
## ======================================================================

dwt.matrix.elems <- function (dx)
{
  dz <- dwt.update(dx, rep(0, dx$N))
  W  <- matrix(0, dx$J+1, dx$N)
  
  for (j in 1:dx$J)
  {
    dz$W[[j]][1] <- 1
    W[j,]        <- idwt(dz)
    dz$W[[j]][1] <- 0
  }

  dz$V[1]    <- 1
  W[dx$J+1,] <- idwt(dz)
  W	
}




## ===================================================================
## Purpose : Produce a wavelet decomposition plot of the dwt
##           class 'dx' using a stacked plot.
## Updated : pfc@stat.ohio-state.edu, Jun 2002.
## ===================================================================

plot.dwt <- function (x, xlab="time", col="black", bg="white",
                      bdcol="black", ...)
{
  xs <- ys <- vlines <- list()
  start      <- start(x$x)[1] + (start(x$x)[2]-1)/frequency(x$x)
  ts         <- seq(from=start, length=x$N, by=deltat(x$x))
  xlabels    <- NULL
  types      <- c("l", rep("h", x$J), "l")
  xs[[1]]    <- ts
  ys[[1]]    <- x$x
  xlabels[1] <- "X"
  
  vn <- 0
  for (j in 1:x$J)
  {
    ks           <- dwt.times(x, j, T)
    xs[[j+1]]    <- sort(ks)
    ys[[j+1]]    <- x$W[[j]][order(ks)]
    xlabels[j+1] <- paste("W", j, sep="")

    if (x$Bj[j]>0)
    {
      delta <- diff(ks)[1]/2
      vlines[[vn+1]] <- c(j,ks[1]  - delta)
      vlines[[vn+2]] <- c(j,ks[x$Bj[j]] + delta)
      vn <- vn + 2
    }
  }

  ks               <- dwt.times(x, x$J, F)
  xs[[x$J+2]]      <- sort(ks)
  ys[[x$J+2]]      <- x$V[order(ks)]
  xlabels[[x$J+2]] <- paste("V",x$J, sep="")

  stackplot(xs, ys, ts, xlabels, types, vlines, xlab=xlab,
            col=col, bg=bg, bdcol=bdcol, ...)
}

