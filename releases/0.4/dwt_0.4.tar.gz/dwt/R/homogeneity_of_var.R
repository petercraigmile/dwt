
modwt.change.var <- function (j, dx, w=modwt.nb(dx,j))
{
  Pk <- (cumsum(w^2)/sum(w^2))[-length(w)]
  N1 <- length(Pk)
  ks <- seq(N1)-1
  
  Dplus <- ks/N1 - Pk
  Dminus <- Pk - (ks-1)/(N1-1)  
  D <- max(c(Dplus, Dminus))

  kplus  <- order(-Dplus)[1]
  kminus <- order(-Dminus)[1]
  k <- ifelse(Dplus[kplus]>Dminus[kminus], kplus, kminus)
  
  list(D=D, k=k)
}
