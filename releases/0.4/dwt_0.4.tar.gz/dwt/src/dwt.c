
/* ======================================================================
// File     : dwt.c
// Purpose  : C code used to implement the DWT.
// Note     : Based on pseudo code from Percival and Walden, 
//            "Wavelet Methods for Time Series Analysis", (2000).
// Updated  : pfc@stat.ohio-state.edu, Sep 2008
// 
// Copyright 2002--2008, Peter F. Craigmile, All Rights Reserved
// Address comments about this software to pfc@stat.ohio-state.edu.
//
// The use of this software is permitted for academic purposes only,
// provided its use is acknowledged.  Commercial use is not allowed
// without the permission of the author.  This software is made available
// AS IS, and no warranty -- about the software, its performance, or
// its conformity to any specification -- is given or implied.
// ======================================================================*/

#include <R.h>
#include <Rmath.h>


/* ======================================================================
// 'dwt.R' functions with circular boundary conditions
// ====================================================================*/

void R_dwt_pyramid_up (double *currV, double *currW, long *M, 
		       double *prevV, double *g, double *h, long *L)
{
  long s, u, t, l;
  double Vs, Vsp1;

  for (t = 0, s = 0; t < (*M); t++, s+=2)
  {
    u = t;    
    Vs = Vsp1 = 0.0;

    for (l = 0; l < (*L); l+=2)
    {
      Vs   += g[l+1]*currV[u] + h[l+1]*currW[u];
      Vsp1 += g[l]  *currV[u] + h[l]  *currW[u];

      u++;
      if (u>=(*M)) u = 0;
    }

    prevV[s]   = Vs;
    prevV[s+1] = Vsp1;
  }
}
 

void R_dwt_pyramid_down (double *currV, long *M, 
			 double *nextV, double *nextW,
			 double *g, double *h, long *L)
{
  long t, u, l;
  double nextV_t, nextW_t;
  
  for (t=0; t<(*M)/2; t++)
  {
    u  = 2*t + 1;
    nextV_t = g[0] * currV[u];
    nextW_t = h[0] * currV[u];

    for (l=1;  l<(*L);  l++)
    {
      u--;
      if (u<0) u = (*M) - 1;
      nextV_t += g[l] * currV[u];
      nextW_t += h[l] * currV[u];
    }

    nextV[t] = nextV_t;
    nextW[t] = nextW_t;
  }
}


