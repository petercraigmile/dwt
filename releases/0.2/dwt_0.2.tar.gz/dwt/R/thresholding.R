

## WMTSA, equation (399)
hard.threshold <- function (x, delta)
{
  ifelse(abs(x) < delta, 0, x)
}


## WMTSA, equation (400a)
soft.threshold <- function (x, delta)
{
  z <- abs(x) - delta
  sign(x) * ifelse(z>0, z, 0)
}


## WMTSA, equation (400d)
universal.threshold <- function (sigma.sq, N)
{
  sqrt(2 * sigma.sq * log(N))
}


## WMTSA, equation (400d)
sure.objective.value <- function (delta, x, sigma.sq.0)
{
  sum((2 * sigma.sq.0 - x^2 + delta)[delta^2 > x^2])
}


## WMTSA, equation (406a)
sure.threshold <- function (x, sigma.sq.0=mad(x))
{
  optimize(sure.threshold.value, x=x, sigma.sq.0=sigma.sq.0)
}



