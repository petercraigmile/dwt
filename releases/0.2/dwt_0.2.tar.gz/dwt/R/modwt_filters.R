

## ======================================================================
## Purpose : Creates a MODWT wavelet filter list object for a given
##           wavelet with name 'name' and DWT scaling coefficients 'scaling'. 
##           If 'scaling' is missing looks for the wavelet filter 'name'
##           from a list of popular wavelet filters.
## Updated : pfc@stat.ohio-state.edu, Jul 2004. 
## ======================================================================

modwt.filter <- function (name, scaling=NULL)
{
  dfilter <- dwt.filter(name, scaling)

  structure(list(name = dfilter$name,
                 g = dfilter$g/sqrt(2),
                 h = dfilter$h/sqrt(2),
                 L = dfilter$L),
            class = "modwt.filter")
}




## ===========================================================================
## Purpose : Calculates the square gain function for the level 'j'
##           wavelet (if wavelet=T) or scaling (if wavelet=F) filter
##           at frequencies 'fs', based on the MODWT 'filter'.
## Updated : pfc@stat.ohio-state.edu, Aug 2002.
## ===========================================================================

modwt.sqgain <- function (fs, filter, j, wavelet=T)
{
  dwt.sqgain(fs, filter, j, wavelet)
}




