
## ======================================================================
## File       : dwt_trend.R
## Purpose    : R/Splus code for trend assessment using the Discrete 
##              Wavelet Transform (DWT).
## Requires   : (1) C function "R_dwt_trend_est_var" dynamically loaded.
##              (2) dwt.R
## References : P. F. Craigmile, P. Guttorp, and D. B. Percival (2004)
##              "Assessing nonlinear trends using the discrete
##              wavelet transform", Environmetrics, 15 (4), 313-335. 
## Created    : pfc@stat.ohio-state.edu, June 2002. 
## ======================================================================


# ======================================================================
# Purpose : Calculate the test for trend statistic for the dwt
#           object 'dx'.
# Created : pfc@stat.ohio-state.edu, June 2002. 
# ======================================================================

dwt.trend.stat <- function (dx)
{
  sumsq(dx$x - mean(dx$x))/sum(dwt.sumsq(dx))
}



# This is deprecated for the moment!
# ======================================================================
# Purpose : Calculates the test for trend statistic for 'reps'
#           realisations of FD(ds) processes.  Base the simulations
#           on the details in the dwt class 'dx'.
# Created : pfc@stat.ohio-state.edu, June 2002. 
# ======================================================================

#fd.dwt.trend.distrib <- function (dx, ds, reps=length(ds))
#{
#  library(longmem)
#  if (length(ds)==1) ds <- rep(ds,reps)
#  
#  sapply(ds, function (d, dx)
#         dwt.trend.stat(dwt.update(dx, fd.sim(dx$N, d))), dx=dx)
#}




# ======================================================================
# Purpose : Return the trend estimate for the dwt class 'dx'.
# Created : pfc@stat.ohio-state.edu, June 2002. 
# ======================================================================

dwt.trend.est <- function (dx)
{
  for (j in 1:dx$J)
    dx$W[[j]][(dx$Bj[j]+1):dx$Nj[j]] <- 0
  idwt(dx)
}





# ======================================================================
# Purpose : Return a vector of 1's and 0's indicating the coefficients
#           of the wavelet vector which are part of the trend estimate.
#           'dx' is the dwt class of interest.
# Created : pfc@stat.ohio-state.edu, October 2001. 
# ======================================================================

dwt.trend.select <- function (dx)
{
  sel <- NULL
  for (j in 1:dx$J)
    sel <- c(sel, rep(1, dx$Bj[j]), rep(0, dx$Mj[j]))
  c(sel, rep(1, dx$Nj[dx$J]))
}



# ======================================================================
# Purpose : Calculate the variance of the dwt class 'dx' trend
#           estimate for a stationary process with 'acvs'.
#           'acvs' is a vector of the lag 0..dx$N-1 acvs.
# Assumes : C function "R_dwt_trend_est_var" is dynamically loaded.
# Created : pfc@stat.ohio-state.edu, June 2002. 
# ======================================================================

#dwt.trend.est.var.fast <- function (dx, acvs)
#{
#  if (!is.loaded("R_dwt_trend_est_var"))
#    stop("The C function 'R_dwt_trend_est_var' must be dynamically loaded.")
#  
#  w <- as.vector(t(dwt.matrix.elems(dx)))
#  z <- double(dx$N)
#  
#  .C("R_dwt_trend_est_var",
#     vars = z, as.integer(c(dx$Bj, dx$Nj[dx$J])),
#     as.double(acvs), as.integer(dx$N),
#     z, as.double(w), as.integer(dx$J))$vars
#}






# ======================================================================
# Purpose : Calculate the variance of the dwt class 'dx' trend
#           estimate for a stationary process with 'acvs'.
#           'acvs' is a vector of the lag 0..dx$N-1 acvs.
# Created : pfc@stat.ohio-state.edu, June 2002. 
# ======================================================================

dwt.trend.est.var <- function (dx, acvs)
{
  W <- dwt.matrix(dx)
  R <- t(W) %*% diag(dwt.trend.select(dx)) %*% W
  diag(R %*% toeplitz(acvs) %*% t(R))
}

