

dwt.as.vector <- function (dx) {

  c(unlist(dx$W), dx$V)
}



dwt.map.vector <- function (dx, w) {

  z <- w
  
  for (j in 1:dx$nlevels) {

    sel <- 1:dx$Nj[j]
    dx$W[[j]] <- z[sel]
    z <- z[-sel]
  }

  dx$V <- z
  dx
}
